#!/bin/bash
make smdk2440a_config
make -j2

